/**
 * The BadStackingException exception should be thrown anytime someone tries to put a larger disk on top of smaller disk.
 * @author Joseph Hentges
 * @version October 5, 2018
 */
public class BadStackingException extends Exception
{
     public BadStackingException()
     {
          super("EXCEPTION -- LARGE DISKS CANNONT STACK ON SMALLER DISKS");
     }
     
}