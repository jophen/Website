/**
 * The TowerFullException exception should be thrown anytime someone tries to add a disk to a full Tower.
 * @author Joseph Hentges
 * @version October 5, 2018
 */
public class TowerFullException extends Exception
{
     public TowerFullException()
     {
          super("EXCEPTION -- TOWER IS FULL");
     }
     
}