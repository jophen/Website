
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;
import java.util.Vector;


/**
 * This is the driver for Lists
 * Test the adding and remove times for different types of lists.
 * Comment out and uncomment the type of list you wish to test.
 * CSC 210 Data Structures
 * Semester 1 | Fall 2018
 * September 28, 2018
 * @author Joseph Hentges
 */

public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //HentgesList myList = new LinkBasedList();
        //HentgesList myList = new ArrayBasedList();
        
        //Java provided built in classes
        //Vector myList = new Vector();
        ArrayList myList = new ArrayList();
        //LinkedList myList = new LinkedList();
        
        System.out.println(myList);
        
        long startTime = System.nanoTime();
        //Add a few items to the list
        for(int i = 0; i < 1000000; i++)
        {
            Random gen = new Random(); //Random Generator
            myList.add(gen.nextInt(100000)); //Add random values up to 100,000
        }
        long endTime = System.nanoTime();
        long output = (endTime - startTime);
        System.out.println("Finished adding 1,000,000 values to the list!");
        System.out.println("Add Time:\n\t" + output + " nano seconds");
        
        startTime = System.nanoTime();
        for(int i = 0; i < 100000; i++)
        {
            myList.remove(i);
        }
        endTime = System.nanoTime();
        output = (endTime - startTime);
        System.out.println("Finshed removing the first 100,000 values in the list!");
        System.out.println("Remove Time:\n\t" + output + " nano seconds");
        
        //Use the code below to view the first 10,000 values in the list. 
        //However, it only works for LinkedBasedList and ArrayBasedList.
        /**
        int[] array = myList.toArray();
        System.out.println("After getting an array of the lists values, here are the first 10,000: ");
        for(int i = 0; i < 10000; i++)
        {
            System.out.println("\t" + array[i]);
        }
        */
        
    }
    
}
